import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
const root=new URL('../',import.meta.url);
const read=file=>readFile(new URL(file,root),'utf8');
const write=(file,value)=>writeFile(new URL(file,root),value);
await mkdir(new URL('docs/',root),{recursive:true});
const config=JSON.parse(await read('config.json'));
let html=await read('source/page.html');
html=html.replace('const path=location.pathname;',"const path=new URLSearchParams(location.search).get('page')||'/';");
html=html.replace('await fetch(url,','await cloudFetch(url,');
html=html.replace('state.menu=r.menu;state.role=r.role;','state.menu=r.menu;state.role=r.role;state.cloudReady=r.ready!==false;');
html=html.replace("header()+'<div class=\"guest-layout\">","header()+(state.cloudReady===false?'<div role=\"status\" style=\"padding:16px;text-align:center;background:#fff1d6;color:#704812;font-size:18px\">系統準備中，目前僅供瀏覽菜單，尚未開放點餐。</div>':'')+'<div class=\"guest-layout\">");
html=html.replace('!state.cart.length||!table||busy||!state.online','state.cloudReady===false||!state.cart.length||!table||busy||!state.online');
html=html.replaceAll("location.replace(state.role==='kitchen'?'/kitchen':'/cashier')","location.replace(siteHref(state.role==='kitchen'?'/kitchen':'/cashier'))");
html=html.replace("location.href='/?table='+e.target.value","location.href=siteHref('/?table='+e.target.value)");
html=html.replaceAll('location.href=&quot;/cashier&quot;','location.href=siteHref(&quot;/cashier&quot;)');
const qrFunction=`function qrcodes(){const cards=Array.from({length:10},(_,i)=>({key:'table-'+(i+1),title:'第 '+String(i+1).padStart(2,'0')+' 桌',href:'/?table='+(i+1)})).concat([{key:'kitchen',title:'廚房出餐',href:'/kitchen'},{key:'cashier',title:'前台結帳',href:'/cashier'}]);return pageTop('桌牌 QR Code','桌牌會使用目前 GitHub Pages 網址，列印前請確認網址。','<button class="btn" data-action="print">列印全部桌牌</button>')+'<div class="qr-grid">'+cards.map(c=>{const href=siteHref(c.href);const image='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(qrSvg(href));return '<article class="qr-card"><h2>'+c.title+'</h2><img class="qrcode" src="'+image+'" alt="'+c.title+' QR Code"><p>湯達人・同桌一起點</p><div class="print-only">'+esc(href)+'</div><div class="actions"><a class="btn small secondary" href="'+image+'" download="'+c.key+'.svg">下載 SVG</a><a class="btn small ghost" href="'+href+'" target="_blank" rel="noopener">開啟入口</a></div></article>';}).join('')+'</div>';}`;
html=html.replace(/function qrcodes\(\)[^\n]*/,()=>qrFunction);
html=html.replace('<script>','<script src="./cloud.js"></script><script src="./qr.js"></script><script>');
await write('docs/index.html',html);
await write('docs/.nojekyll','');
await write('docs/cloud.js',(await read('source/cloud.js')).replace('/*__CONFIG__*/{}',()=>JSON.stringify(config)));
await write('docs/qr.js','(()=>{'+(await read('source/qr.mjs')).replaceAll('export function','function')+'\nwindow.qrSvg=qrSvg;})();');
let worker=await read('source/worker.js');
const menu=JSON.parse(await read('source/menu.json'));
worker=worker.replace('/*__MENU__*/[]',()=>JSON.stringify(menu))
 .replace("/*__HTML__*/''","''").replace('/*__QRS__*/{}','{}');
await write('supabase/functions/ordering/worker.js',worker);
await mkdir(new URL('deploy/',root),{recursive:true});
const edge=(await read('supabase/functions/ordering/index.ts'))
 .replace("import worker from './worker.js';",()=>worker.replace('export default {','const worker = {'))
 .replace("import {createDB} from './database.js';",()=>'\n__DATABASE_ADAPTER__\n');
const adapter=databaseAdapter(await read('supabase/functions/ordering/database.js'));
await write('deploy/index.ts',edge.replace('__DATABASE_ADAPTER__',()=>adapter));
console.log('Built GitHub Pages frontend and Supabase ordering backend.');

function databaseAdapter(text){return text.replaceAll('export function','function');}
