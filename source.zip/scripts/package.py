from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
out=root.parent/'outputs/tangdaren-github-pages-supabase.zip'
with ZipFile(out,'w',ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  rel=p.relative_to(root)
  if not p.is_file() or any(x in {'node_modules','.git','.supabase','__pycache__','.temp'} for x in rel.parts):continue
  if p.name.startswith('.env') and p.name!='.env.example':raise RuntimeError('Secret configuration file in artifact')
  if p.suffix in {'.sqlite','.p12','.jks','.keystore'}:raise RuntimeError('Private file in artifact')
  z.write(p,rel.as_posix())
with ZipFile(out) as z:assert z.testzip() is None
print(str(out))
