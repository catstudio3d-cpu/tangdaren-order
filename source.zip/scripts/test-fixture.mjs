import {createHmac} from 'node:crypto';
import {PGlite} from '@electric-sql/pglite';
import {readFile} from 'node:fs/promises';
import {createDB} from '../supabase/functions/ordering/database.js';
const pg=new PGlite();
await pg.exec('CREATE ROLE anon; CREATE ROLE authenticated;');
await pg.exec(await readFile(new URL('../supabase/migrations/202611200001_ordering.sql',import.meta.url),'utf8'));
await pg.exec('SET search_path TO ordering, pg_catalog;');
const connection={async unsafe(sql,args=[]){let result;try{result=await pg.query(sql,args);}catch(error){console.error(sql,error.message);throw error;}const rows=result.rows;rows.count=result.affectedRows||0;return rows;}};
const db=createDB(connection);

export const env={DB:db,SESSION_SECRET:'test-secret',CASHIER_PIN:'246810',KITCHEN_PIN:'135790'};

env.STAFF_PASSWORD_SALT='test-staff-salt';env.CASHIER_PASSWORD_HASH=createHmac('sha256',env.STAFF_PASSWORD_SALT).update(env.CASHIER_PIN).digest('hex');env.KITCHEN_PASSWORD_HASH=createHmac('sha256',env.STAFF_PASSWORD_SALT).update(env.KITCHEN_PIN).digest('hex');
