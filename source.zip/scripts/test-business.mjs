import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {Script} from 'node:vm';
import worker from '../supabase/functions/ordering/worker.js';
import {env} from './test-fixture.mjs';
import {qrMatrix} from '../source/qr.mjs';
const origin='https://orders.test';let passes=0;
async function request(path,body,cookie){return worker.fetch(new Request(origin+path,{method:body?'POST':'GET',headers:{...(body?{'Origin':origin,'Content-Type':'application/json'}:{}),...(cookie?{Cookie:cookie}:{})},...(body?{body:JSON.stringify(body)}:{})}),env)}
async function call(path,body,cookie,status=200){const r=await request(path,body,cookie);const j=await r.json();assert.equal(r.status,status,JSON.stringify(j));passes++;return j}
async function login(role,pin){const r=await request('/api/login',{role,pin});assert.equal(r.status,200);return r.headers.get('set-cookie').split(';')[0]}
env.ADMIN_USERNAME='admin';env.ADMIN_PASSWORD_SALT='test-salt';
const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(env.ADMIN_PASSWORD_SALT),{name:'HMAC',hash:'SHA-256'},false,['sign']);
env.ADMIN_PASSWORD_HASH=Array.from(new Uint8Array(await crypto.subtle.sign('HMAC',key,new TextEncoder().encode('test-admin-password')))).map(x=>x.toString(16).padStart(2,'0')).join('');
new Script(readFileSync(new URL('../source/page.html',import.meta.url),'utf8').match(/<script>([\s\S]*)<\/script>/)[1]);passes++;
await call('/api/board',null,null,401);
await call('/api/table?table=11',null,null,400);
const cashier=await login('cashier','246810'),kitchen=await login('kitchen','135790');
const ar=await request('/api/login',{username:'admin',pin:'test-admin-password'});const admin=ar.headers.get('set-cookie').split(';')[0];
await call('/api/report',null,kitchen,403);
assert.equal((await request('/api/expense',{day:'2026-11-19',amount:1,category:'食材'},kitchen)).status,403);passes++;
const order=(table,generation,items=[{id:'soup-chicken',price:150,qty:1,note:'不要薑'}])=>({table,generation,requestId:crypto.randomUUID(),items});
const a=order(1,1);await call('/api/order',a);await call('/api/order',a);
const concurrent=Array.from({length:10},()=>order(3,1,[{id:'egg',price:20,qty:1}]));
await Promise.all(concurrent.map(x=>call('/api/order',x)));
await Promise.all(concurrent.map(x=>call('/api/order',x)));
assert.equal((await call('/api/table?table=3')).lines.length,10);
assert.equal((await call('/api/table?table=3')).total,200);
assert.equal((await call('/api/table?table=1')).lines.length,1);
await call('/api/order',order(1,1,[{id:'rice-pork',price:30,qty:2}]));
let table=await call('/api/table?table=1');assert.equal(table.total,210);assert.equal(table.lines.length,2);
await call('/api/order',order(2,1));assert.equal((await call('/api/table?table=2')).total,150);
await call('/api/order',order(1,1,[{id:'rice-pork',price:1,qty:1}]),null,409);
const pay={billId:'1:1',expectedTotal:210,expectedCount:2,received:300,payment:'現金'};
await call('/api/checkout',pay,cashier,409);
for(const l of table.lines)await call('/api/serve',{id:l.id,served:true},kitchen);
await call('/api/order',order(1,1,[{id:'egg',price:20,qty:1}]));
await call('/api/checkout',pay,cashier,409);
table=await call('/api/table?table=1');for(const l of table.lines)await call('/api/serve',{id:l.id,served:true},kitchen);
const paid=await call('/api/checkout',{...pay,expectedTotal:230,expectedCount:3},cashier);assert.equal(paid.change,70);
await call('/api/checkout',{...pay,expectedTotal:230,expectedCount:3},cashier,409);
table=await call('/api/table?table=1');assert.equal(table.generation,2);assert.equal(table.lines.length,0);
await call('/api/order',order(1,1),null,409);
await call('/api/order',order(1,2,[{id:'rice-pork',price:30,qty:1}]));assert.equal((await call('/api/table?table=1')).total,30);
await call('/api/menu-update',{id:'rice-pork',price:35,available:false},admin);
await call('/api/order',order(1,2,[{id:'rice-pork',price:35,qty:1}]),null,400);
assert.equal((await call('/api/table?table=1')).total,30);
await call('/api/expense',{day:'2026-11-19',category:'食材',amount:80,note:'=bad()'},admin);
const today=new Date(Date.now()+28800000).toISOString().slice(0,10);let report=await call('/api/report?day='+today,null,admin);assert.equal(report.revenue,230);assert.equal(report.bills.length,1);
assert.equal((await call('/api/report?day=2026-11-19',null,admin)).expense,80);
const csv=await request('/api/export?day=2026-11-19',null,admin);assert.match(await csv.text(),/'=bad\(\)/);passes++;
const csrf=await worker.fetch(new Request(origin+'/api/order',{method:'POST',headers:{Origin:'https://evil.test'},body:'{}'}),env);assert.equal(csrf.status,403);passes++;
await call('/api/serve',{id:'not-real',served:true},kitchen,409);
for(let t=1;t<=10;t++){const m=qrMatrix('https://tangdaren-order-2026.murco007.chatgpt.site/?table='+t);assert.equal(m.length,41);assert.equal(m.flat().length,1681);passes++}
// Verify business-day boundary, not the database host timezone.
await env.DB.prepare("UPDATE bills SET paid_at='2026-11-19T16:01:00.000Z' WHERE id='1:1'").run();
assert.equal((await call('/api/report?day=2026-11-20',null,admin)).revenue,230);
assert.equal((await call('/api/report?day=2026-11-19',null,admin)).revenue,0);
await call('/api/login',{username:'admin',pin:'wrong'},null,401);
await call('/api/login',{username:'wrong',pin:'test-admin-password'},null,401);
assert.ok(await login('cashier','246810')); 
const adminLogin=await call('/api/login',{username:'admin',pin:'test-admin-password'});assert.equal(adminLogin.role,'admin');
assert.ok(await login('kitchen','135790'));

for(const staff of [cashier,kitchen]){
 for(const endpoint of ['/api/report','/api/export'])await call(endpoint,null,staff,403);
 await call('/api/menu-update',{id:'egg',price:20,available:true},staff,403);
 await call('/api/expense',{day:'2026-11-19',amount:1,category:'食材'},staff,403);
 for(const page of ['/reports','/settings','/qrcodes']){const r=await request(page,null,staff);assert.equal(r.status,302);assert.equal(r.headers.get('location'),staff===kitchen?'/kitchen':'/cashier');passes++;}
}
await call('/api/serve',{id:'not-real',served:true},cashier,403);
await call('/api/checkout',{},kitchen,403);
for(const page of ['/cashier','/kitchen','/reports','/settings','/qrcodes'])assert.equal((await request(page,null,admin)).status,200);

const dish={name:'測試自訂餐點',category:'私房小菜',description:'自訂說明',image:'data:image/png;base64,iVBORw0KGgo=',price:65,available:true};
await call('/api/menu-save',dish,null,401);
for(const staff of [cashier,kitchen])await call('/api/menu-save',dish,staff,403);
await call('/api/menu-save',{...dish,price:-1},admin,400);
await call('/api/menu-save',{...dish,image:'javascript:alert(1)'},admin,400);
const saved=await call('/api/menu-save',dish,admin);
let custom=(await call('/api/menu')).menu.find(p=>p.id===saved.id);assert.equal(custom.name,dish.name);assert.equal(custom.image,dish.image);
await call('/api/order',order(4,1,[{id:saved.id,price:65,qty:1}]));
await call('/api/menu-save',{...dish,id:saved.id,name:'修改後名稱',price:70},admin);
assert.equal((await call('/api/table?table=4')).total,65);
assert.equal((await call('/api/table?table=4')).lines[0].name,dish.name);
custom=(await call('/api/menu')).menu.find(p=>p.id===saved.id);assert.equal(custom.price,70);
await call('/api/menu-update',{id:saved.id,price:75,available:false},admin);
await call('/api/order',order(4,1,[{id:saved.id,price:75,qty:1}]),null,400);
console.log('PASS: '+passes+' API, ordering, authorization, checkout, reporting, QR and syntax checks.');
