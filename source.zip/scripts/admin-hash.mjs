import {createHmac,randomBytes} from 'node:crypto';
if(!process.stdin.isTTY)throw Error('Run in an interactive terminal');
process.stdout.write('輸入新的管理員密碼（輸入不顯示）：');
process.stdin.setRawMode(true);process.stdin.resume();process.stdin.setEncoding('utf8');let password='';
process.stdin.on('data',chunk=>{for(const key of chunk){if(key==='\u0003'){process.stdin.setRawMode(false);process.exit(1);}if(key==='\r'||key==='\n'){process.stdin.setRawMode(false);process.stdin.pause();if(password.length<8){console.error('\n密碼至少 8 字元');process.exit(1);}const salt=randomBytes(32).toString('hex');console.log('\nADMIN_PASSWORD_SALT='+salt+'\nADMIN_PASSWORD_HASH='+createHmac('sha256',salt).update(password).digest('hex'));return;}if(key==='\u007f')password=password.slice(0,-1);else if(key>=' ')password+=key;}});
