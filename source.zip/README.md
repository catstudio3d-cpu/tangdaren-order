# 湯達人 QR Code 線上點餐系統

GitHub Pages 靜態前端 + Supabase PostgreSQL / Edge Function。

- 網站：https://catstudio3d-cpu.github.io/tangdaren-order/
- 後端專案：knwxopwntkhmmijxrsps
- 本儲存庫不含實際員工密碼、密碼雜湊、營業訂單或營收資料。config.json 只有公開的 Supabase 設定。

## 目前部署狀態

已建立 ordering 私有 schema、7 張業務表及 1 張私有 runtime_config 設定表；所有資料表啟用 RLS，匿名與 authenticated 不得直接存取。既有 public.SoupMaster 保留。ordering Edge Function 已部署。

登入設定尚未搬移，公開菜單可瀏覽，但後端暫不接受點餐或員工登入。完成私有登入設定後再進行營業驗收。

## 發布

GitHub Settings → Pages → Deploy from a branch → main /docs。執行 npm ci、npm run build，將 docs 與原始碼提交 main 後會自動重新發布。

## 後端

Supabase Functions 的 ordering 使用 supabase/functions/ordering/index.ts、worker.js、database.js。deploy/index.ts 是相同程式的單檔版本。函式自行驗證員工簽章 session，公開點餐不需 Supabase 使用者 JWT，因此 verify_jwt=false。DB 連線使用執行環境提供的 SUPABASE_DB_URL，或自行設定的 ORDERING_DB_URL，prepare=false，交易內設置私有 schema 搜尋路徑並取得 advisory lock，保持重複送單及結帳保護。

工作階段密鑰與密碼雜湊只存於 ordering.runtime_config.settings（id=1）或同名 Edge Function secrets，不能提交儲存庫。設定鍵為 SITE_URL、SESSION_SECRET、ADMIN_USERNAME、ADMIN_PASSWORD_HASH、ADMIN_PASSWORD_SALT、STAFF_PASSWORD_SALT、CASHIER_PASSWORD_HASH、KITCHEN_PASSWORD_HASH。密碼雜湊均使用 HMAC-SHA256。

## 網址

首頁採 ?table=1；後台採 ?page=/cashier、?page=/kitchen、?page=/reports、?page=/settings、?page=/qrcodes。後台權限全部在伺服器驗證。桌牌 QR Code 依實際 GitHub Pages 網址產生，更換網址需重新列印。CSV 經帶有登入憑證的請求下載，密鑰不放在網址。

## 功能與資料

保留點餐、同桌加點、廚房出餐、前台結帳、管理員報表與餐點圖片管理，頁尾包含卡特思科技標誌及 LINE ID：murco007。電腦、Android 與雲端資料庫獨立，既有訂單不自動轉入。

## 驗證

Node 24：npm ci && npm run build && npm test。SQL 轉譯與靜態路徑檢查，以及 PGlite PostgreSQL 引擎上的 104 項業務檢查通過；scripts/test-fixture.mjs 中的密碼僅為測試用虛構值。完成正式登入設定後需測試實際雲端點餐→出餐→結帳與報表。
