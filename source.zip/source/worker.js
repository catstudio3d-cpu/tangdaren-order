const MENU = /*__MENU__*/[];
const HTML = /*__HTML__*/'';
const QRS = /*__QRS__*/{};
const json = (v,status=200,headers={}) => new Response(JSON.stringify(v),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers}});
const fail=(msg,status=400)=>{throw Object.assign(new Error(msg),{status})};
const validTable=n=>Number.isInteger(n)&&n>=1&&n<=10;
const now=()=>new Date().toISOString();
const dayNow=()=>new Date(Date.now()+28800000).toISOString().slice(0,10);
async function signature(s,secret){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);return Array.from(new Uint8Array(await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(s)))).map(x=>x.toString(16).padStart(2,'0')).join('')}
async function roleOf(req,env){const cookie=req.headers.get('cookie')?.match(/(?:^|;\s*)staff=([^;]+)/)?.[1]; if(!cookie||!env.SESSION_SECRET)return null;const [role,exp,sig]=cookie.split('.');if(!['admin','kitchen','cashier'].includes(role)||Number(exp)<Date.now())return null;return await signature(role+'.'+exp,env.SESSION_SECRET)===sig?role:null}
async function menu(db){const {results:overrides}=await db.prepare('SELECT * FROM menu_overrides').all();const {results:custom}=await db.prepare('SELECT * FROM menu_custom ORDER BY rowid').all();const products=[...MENU,...custom.filter(p=>!MENU.some(x=>x.id===p.id))];return products.map(p=>{const edit=custom.find(x=>x.id===p.id);const override=overrides.find(x=>x.id===p.id);return {...p,...edit,...override,available:(override?.available??edit?.available??(p.available===false?0:1))!==0}});}
async function tableState(db,t){const state=await db.prepare('SELECT generation FROM dining_tables WHERE table_no=?').bind(t).first();const generation=state?.generation||1;const bill=await db.prepare("SELECT * FROM bills WHERE table_no=? AND generation=? AND status='open'").bind(t,generation).first();const lines=bill?(await db.prepare('SELECT * FROM lines WHERE bill_id=? ORDER BY created_at,id').bind(bill.id).all()).results:[];return {table:t,generation,bill,lines,total:lines.reduce((a,l)=>a+l.price*l.qty,0)};}
async function api(req,env,u){
 const db=env.DB;if(!db)fail('尚未連接資料庫，請聯絡管理員。',503);
 const path=u.pathname;const role=await roleOf(req,env);
 if(req.method==='POST'&&req.headers.get('origin')!==u.origin)fail('請從本站操作。',403);
 const b=req.method==='POST'?await req.json().catch(()=>fail('資料格式錯誤')):{};
 if(path==='/api/login'&&req.method==='POST'){
  if(!env.SESSION_SECRET||!env.CASHIER_PASSWORD_HASH||!env.KITCHEN_PASSWORD_HASH)fail('尚未設定員工登入，請聯絡管理員。',503);
  const ip=req.headers.get('cf-connecting-ip')||'local';const k=await signature(ip,env.SESSION_SECRET);const minute=Math.floor(Date.now()/600000);
  await db.prepare('INSERT INTO login_attempts(key,attempts,window) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET attempts=CASE WHEN window=? THEN attempts+1 ELSE 1 END, window=?').bind(k,minute,minute,minute).run();
  const a=await db.prepare('SELECT attempts FROM login_attempts WHERE key=?').bind(k).first();if(a.attempts>12)fail('嘗試次數過多，請於 10 分鐘後重試。',429);
  const admin=typeof b.username==='string'&&b.username.trim().length>0;
  const r=admin?'admin':b.role==='kitchen'?'kitchen':'cashier';
  if(admin){if(b.username!==env.ADMIN_USERNAME||!env.ADMIN_PASSWORD_HASH||!env.ADMIN_PASSWORD_SALT||await signature(String(b.pin||''),env.ADMIN_PASSWORD_SALT)!==env.ADMIN_PASSWORD_HASH)fail('帳號或密碼不正確。',401);}
  else if(await signature(String(b.pin||''),env.STAFF_PASSWORD_SALT)!==(r==='kitchen'?env.KITCHEN_PASSWORD_HASH:env.CASHIER_PASSWORD_HASH))fail('帳號或密碼不正確。',401);
  const payload=r+'.'+(Date.now()+43200000);const token=payload+'.'+await signature(payload,env.SESSION_SECRET);
  return json({role:r},200,{'Set-Cookie':'staff='+token+'; HttpOnly; '+(env.LAN_MODE?'':'Secure; ')+'SameSite=Strict; Path=/; Max-Age=43200'});
 }
 if(path==='/api/logout'&&req.method==='POST')return json({ok:true},200,{'Set-Cookie':'staff=; HttpOnly; '+(env.LAN_MODE?'':'Secure; ')+'SameSite=Strict; Path=/; Max-Age=0'});
 if(path==='/api/menu'&&req.method==='GET')return json({menu:await menu(db),role,sourceDate:'2026-11-19'});
 if(path==='/api/table'&&req.method==='GET'){const t=Number(u.searchParams.get('table'));if(!validTable(t))fail('桌號必須為 1–10');return json(await tableState(db,t));}
 if(path==='/api/order'&&req.method==='POST'){
  const t=Number(b.table),g=Number(b.generation);if(!validTable(t)||!Number.isInteger(g)||g<1)fail('桌號或訂單已失效。');
  if(!/^[a-zA-Z0-9-]{16,64}$/.test(b.requestId||''))fail('缺少送單識別碼。');
  if(!Array.isArray(b.items)||!b.items.length||b.items.length>30)fail('請選擇 1–30 項餐點。');
  const products=await menu(db);const stamp=now();const billId=t+':'+g;
  const items=b.items.map((x,i)=>{const p=products.find(p=>p.id===x.id);if(!p||!p.available)fail('餐點已停售，請重新選擇。');if(!Number.isInteger(x.qty)||x.qty<1||x.qty>20)fail('每項數量需為 1–20。');const note=String(x.note||'').trim();if(note.length>200)fail('備註最多 200 字。');if(x.price!==p.price)fail('餐點價格已更新，請重新整理後確認。',409);return {id:b.requestId+'-'+i,p,qty:x.qty,note};});
  const existing=await db.prepare('SELECT bill_id FROM lines WHERE id=?').bind(items[0].id).first();if(existing){if(existing.bill_id!==billId)fail('重複識別碼。',409);return json({ok:true,duplicate:true});}
  const statements=[db.prepare('INSERT OR IGNORE INTO dining_tables(table_no,generation) VALUES(?,1)').bind(t),db.prepare("INSERT OR IGNORE INTO bills(id,table_no,generation,status,opened_at) SELECT ?,?,?,'open',? WHERE EXISTS(SELECT 1 FROM dining_tables WHERE table_no=? AND generation=?)").bind(billId,t,g,stamp,t,g),...items.map(x=>db.prepare("INSERT OR IGNORE INTO lines(id,bill_id,product_id,name,price,qty,note,created_at) SELECT ?,?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM bills WHERE id=? AND status='open') AND EXISTS(SELECT 1 FROM dining_tables WHERE table_no=? AND generation=?)").bind(x.id,billId,x.p.id,x.p.name,x.p.price,x.qty,x.note,stamp,billId,t,g))];
  await db.batch(statements);const inserted=await db.prepare('SELECT id FROM lines WHERE id=?').bind(items[0].id).first();if(!inserted)fail('這桌已結帳，請重新整理再點餐。',409);return json({ok:true});
 }
 if(!role)fail('請先登入員工後台。',401);
 if(path==='/api/board'&&req.method==='GET'){const {results}=await db.prepare("SELECT b.*,l.id AS line_id,l.product_id,l.name,l.price,l.qty,l.note,l.created_at,l.served FROM bills b JOIN lines l ON l.bill_id=b.id WHERE b.status='open' ORDER BY b.opened_at,l.created_at,l.id").all();return json({rows:results,role});}
 if(path==='/api/serve'&&req.method==='POST'){if(!['admin','kitchen'].includes(role))fail('此功能僅供廚房或管理員使用。',403);if(typeof b.served!=='boolean')fail('出餐狀態錯誤');const r=await db.prepare("UPDATE lines SET served=? WHERE id=? AND bill_id IN (SELECT id FROM bills WHERE status='open')").bind(b.served?1:0,String(b.id)).run();if(!r.meta.changes)fail('訂單已結束。',409);return json({ok:true});}
 if(!['admin','cashier'].includes(role))fail('此功能僅供結帳前台使用。',403);
 if(path==='/api/checkout'&&req.method==='POST'){
  if(!['現金','刷卡','行動支付'].includes(b.payment))fail('付款方式錯誤');
  const bill=await db.prepare("SELECT * FROM bills WHERE id=? AND status='open'").bind(String(b.billId)).first();if(!bill)fail('此帳單已結帳或不存在。',409);
  if(!Number.isInteger(b.expectedTotal)||!Number.isInteger(b.expectedCount)||!Number.isInteger(b.received)||b.received<b.expectedTotal)fail('收款金額不足或格式錯誤。');
  const paid=now();const result=await db.batch([
   db.prepare("UPDATE bills SET status='paid',paid_at=?,payment=?,received=? WHERE id=? AND status='open' AND (SELECT COUNT(*) FROM lines WHERE bill_id=?)=? AND (SELECT COALESCE(SUM(price*qty),0) FROM lines WHERE bill_id=?)=? AND NOT EXISTS(SELECT 1 FROM lines WHERE bill_id=? AND served=0)").bind(paid,b.payment,b.received,bill.id,bill.id,b.expectedCount,bill.id,b.expectedTotal,bill.id),
   db.prepare("UPDATE dining_tables SET generation=generation+1 WHERE table_no=? AND generation=? AND EXISTS(SELECT 1 FROM bills WHERE id=? AND status='paid')").bind(bill.table_no,bill.generation,bill.id)
  ]);if(!result[0].meta.changes)fail('帳單已變動或仍有未出餐品項，請重新確認。',409);return json({ok:true,change:b.received-b.expectedTotal});
 }
 if(role!=='admin')fail('此功能僅供管理員使用。',403);
 if(path==='/api/menu-save'&&req.method==='POST'){
  const name=String(b.name||'').trim(),description=String(b.description||'').trim(),image=String(b.image||'');
  if(!name||name.length>80||description.length>500||!['原味燉盅','暖心套餐','廣東腸粉','飯麵主食','私房小菜','家傳甜湯'].includes(b.category)||!Number.isInteger(b.price)||b.price<0||b.price>99999||typeof b.available!=='boolean')fail('請確認名稱、分類與價格。');
  if(image.length>700000||image&&!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/]+=*$/.test(image)&&!/^https:\/\/[^\s"<>]+$/.test(image)&&!MENU.some(p=>p.image===image))fail('請上傳圖片或使用 HTTPS 圖片網址。');
  const products=await menu(db);if(b.id&&!products.some(p=>p.id===b.id))fail('找不到餐點。',404);const id=b.id||'custom-'+crypto.randomUUID();
  await db.batch([db.prepare('INSERT INTO menu_custom(id,name,category,description,image,price,available) VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,category=excluded.category,description=excluded.description,image=excluded.image,price=excluded.price,available=excluded.available').bind(id,name,b.category,description,image,b.price,b.available?1:0),db.prepare('DELETE FROM menu_overrides WHERE id=?').bind(id)]);return json({ok:true,id});
 }
 if(path==='/api/menu-update'&&req.method==='POST'){if(!(await menu(db)).some(p=>p.id===b.id)||!Number.isInteger(b.price)||b.price<0||b.price>99999||typeof b.available!=='boolean')fail('價格或餐點資料錯誤。');await db.prepare('INSERT INTO menu_overrides(id,price,available) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET price=excluded.price,available=excluded.available').bind(b.id,b.price,b.available?1:0).run();return json({ok:true});}
 if(path==='/api/expense'&&req.method==='POST'){if(!/^\d{4}-\d{2}-\d{2}$/.test(b.day)||!Number.isInteger(b.amount)||b.amount<=0||b.amount>9999999||!['食材','人事','租金','水電','其他'].includes(b.category))fail('請確認支出日期、分類與正整數金額。');await db.prepare('INSERT INTO expenses(id,day,category,amount,note,created_at) VALUES(?,?,?,?,?,?)').bind(crypto.randomUUID(),b.day,b.category,b.amount,String(b.note||'').slice(0,200),now()).run();return json({ok:true});}
 if((path==='/api/report'||path==='/api/export')&&req.method==='GET'){
  const day=u.searchParams.get('day')||dayNow();if(!/^\d{4}-\d{2}-\d{2}$/.test(day))fail('日期格式錯誤');
  const bills=(await db.prepare("SELECT b.*,SUM(l.price*l.qty) AS total,SUM(l.qty) AS quantity FROM bills b JOIN lines l ON l.bill_id=b.id WHERE b.status='paid' AND substr(datetime(b.paid_at,'+8 hours'),1,10)=? GROUP BY b.id ORDER BY b.paid_at DESC").bind(day).all()).results;
  const expenses=(await db.prepare('SELECT * FROM expenses WHERE day=? ORDER BY created_at DESC').bind(day).all()).results;
  const sales=(await db.prepare("SELECT l.name,SUM(l.qty) AS quantity,SUM(l.qty*l.price) AS total FROM lines l JOIN bills b ON b.id=l.bill_id WHERE b.status='paid' AND substr(datetime(b.paid_at,'+8 hours'),1,10)=? GROUP BY l.name ORDER BY quantity DESC").bind(day).all()).results;
  if(path==='/api/export'){const cell=v=>'"'+String(typeof v==='string'&&/^[=+@\-]/.test(v)?"'"+v:v??'').replaceAll('"','""')+'"';const rows=[['日期','類型','帳單／分類','桌號','金額','付款方式','備註'],...bills.map(x=>[day,'營收',x.id,x.table_no,x.total,x.payment,'']),...expenses.map(x=>[day,'支出',x.category,'',-x.amount,'',x.note])];return new Response('\ufeff'+rows.map(x=>x.map(cell).join(',')).join('\r\n'),{headers:{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':'attachment; filename="tangdaren-'+day+'.csv"','Cache-Control':'no-store'}});}
  return json({day,bills,expenses,sales,revenue:bills.reduce((a,x)=>a+x.total,0),expense:expenses.reduce((a,x)=>a+x.amount,0)});
 }
 fail('找不到此功能。',404);
}
export default {async fetch(req,env){try{const u=new URL(req.url);if(u.pathname.startsWith('/api/'))return await api(req,env,u);if(req.method!=='GET')return new Response('Method not allowed',{status:405});const pageRole=await roleOf(req,env);if(u.pathname!=='/'&&!u.pathname.startsWith('/api/')&&pageRole&&pageRole!=='admin'){const home=pageRole==='kitchen'?'/kitchen':'/cashier';if(u.pathname!==home)return new Response(null,{status:302,headers:{Location:home,'Cache-Control':'no-store'}});}if(u.pathname.startsWith('/qr/')){const svg=(env.QR_CODES||QRS)[u.pathname.slice(4)];return new Response(svg||'Not found',{status:svg?200:404,headers:{'Content-Type':'image/svg+xml','Cache-Control':'public, max-age=3600'}});}if(!['/','/kitchen','/cashier','/qrcodes','/reports','/settings'].includes(u.pathname))return new Response('Not found',{status:404});return new Response(env.PUBLIC_ORIGIN?HTML.replaceAll('https://tangdaren-order-2026.murco007.chatgpt.site',env.PUBLIC_ORIGIN):HTML,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; img-src 'self' https: data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"}});}catch(e){return json({error:e.status?e.message:'服務暫時無法使用，請重試。'},e.status||500);}}};
